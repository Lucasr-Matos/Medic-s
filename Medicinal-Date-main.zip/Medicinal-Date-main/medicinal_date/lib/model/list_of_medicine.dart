import 'package:medicinal_date/model/Medicine.dart';

List<Medicine> medicine = [];