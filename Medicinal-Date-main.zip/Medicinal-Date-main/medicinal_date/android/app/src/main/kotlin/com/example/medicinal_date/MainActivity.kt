package com.example.medicinal_date

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
